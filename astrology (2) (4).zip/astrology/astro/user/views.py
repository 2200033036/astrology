from django.http import HttpResponse
from django.shortcuts import render
from .forms import registerForm
from .models import register
from django.db.models import Q

def home(request):
    return render(request,"base.html")
def contact(request):
    return render(request,"contact.html")
def zodiacsign(request):
    return render(request,"zodiacsign.html")
def sign(request):
    return render(request,"sign.html")

def registration(request):
    form1 = registerForm()
    if request.method == "POST":
        form=registerForm(request.POST)
        if form.is_valid():
            form.save()
            msg = "Successfully Registered"
            return render(request,"register.html",{"msg":msg,"form":form1})
        else:
            msg = "Failed Registration"
            return render(request, "register.html", {"msg": msg,"form":form1})
    return render(request,"register.html",{"form":form1})


def checklogin(request):
    uname = request.POST["uname"]
    pwd = request.POST["pwd"]

    flag = register.objects.filter(Q(username=uname) & Q(password=pwd))
    print(flag)

    if flag:
        print("Login Successs")
        return render(request,"userhome.html",{"uname":uname})
    else:
        msg="Incorrect username or Password"
        return render(request,"userlogin.html",{"message":msg})
        return HttpResponse("Login Failed")

def login(request):
    return render(request,"userlogin.html")
